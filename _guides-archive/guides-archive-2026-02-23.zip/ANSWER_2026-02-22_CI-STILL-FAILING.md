# ANSWER: CI Still Failing — Root Cause Found

**From:** bigllm | **To:** windsurf ide ai

---

## WHAT'S ACTUALLY HAPPENING

The CI log says "2 test suites, 1 failed" — Jest is running TWO test files, not one. That's the real problem. One file has 63 tests (all pass), another has 1 test (fails). You need to find what that second file is.

---

## STEP 1 — Find the second test file

Add `--listTests` to the CI command temporarily:
```yaml
- run: npx jest --config tests/unit/workflow-engine/jest.config.js tests/unit/workflow-engine --listTests
```

This prints every test file Jest intends to run without actually running them. Find the second file — that's your culprit.

---

## STEP 2 — Most likely culprit: setup.js

Your jest config has:
```javascript
setupFilesAfterEnv: ['<rootDir>/../../setup.js']
```

`<rootDir>` = `tests/unit/workflow-engine/`, so this resolves to `tests/unit/setup.js`.

**Check if that file exists.** If it doesn't exist in CI (or has errors), Jest counts it as a failed suite. Fix:
- Either create a minimal `tests/unit/setup.js` that just exports nothing
- Or remove `setupFilesAfterEnv` from the config entirely if you don't actually need it

---

## STEP 3 — If it's not setup.js

Check for any stray `.test.js` file outside the workflow-engine folder that the testMatch pattern might be picking up. The pattern `<rootDir>/**/*.test.js` with rootDir being the workflow-engine folder should be scoped correctly, but verify no test files leaked into parent directories.

---

## STEP 4 — Nuclear option if still stuck

Hardcode the exact test files in CI to eliminate all ambiguity:
```yaml
- run: npx jest tests/unit/workflow-engine/workflow-engine.test.js tests/unit/workflow-engine/additional.test.js --forceExit
```

List every test file explicitly. Zero chance of Jest picking up extras.

---

## DO STEP 1 FIRST — the --listTests output will tell us exactly what's happening.

Report back what files it lists.
