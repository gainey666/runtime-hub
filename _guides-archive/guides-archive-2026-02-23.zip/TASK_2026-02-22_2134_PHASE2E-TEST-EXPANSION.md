# TASK: Phase 2E — Test Suite Expansion

**From:** bigllm | **To:** windsurf ide ai
**Priority:** MEDIUM
**Do this AFTER:** PHASE2D-PLUGIN-FOUNDATION is complete and committed

---

## 🎯 OBJECTIVE

Expand the test suite to cover the new modular architecture, plugin system, and performance baselines. Goal: meaningful coverage increase, not just count inflation.

---

## 📋 ACCEPTANCE CRITERIA

### New Test Areas
- [ ] **Plugin system** — at least 5 tests: load valid plugin, load invalid plugin, plugin with bad port def, duplicate node type, empty plugins dir
- [ ] **Node adapter performance** — benchmark each of the 26 executor functions, assert each runs in <5ms
- [ ] **Data flow integration** — expand existing 6 data flow tests with at least 4 more covering edge cases (null input, chained nodes, error propagation)
- [ ] **Save/Load round-trip** — at least 3 tests: save workflow → load it back → assert node graph is identical

### Quality
- [ ] No test just checks that a function exists — all tests assert meaningful behavior
- [ ] All new tests follow existing test file patterns in `tests/unit/`
- [ ] Final count: 31 existing + all new tests passing

---

## 🔍 WHERE TO LOOK

```
tests/unit/workflow-engine/   ← existing test patterns to follow
src/engine/node-adapters.js  ← 26 functions to benchmark
src/engine/plugin-loader.js  ← plugin tests target (from PHASE2D)
```

---

## ⚠️ CONSTRAINTS

- Tests only — do not modify source files (unless fixing a genuine bug revealed by a test)
- Performance benchmarks: use `performance.now()` or Jest's built-in timing, not external libs

---

## 📤 REPORT BACK

File: `guides back/DONE_2026-02-22_PHASE2E-TEST-EXPANSION.md`
Include: test count before/after, test categories added, any source bugs found and fixed, git commit hash.
Blocker? → `guides back/BLOCKED_2026-02-22_PHASE2E-TEST-EXPANSION.md`
