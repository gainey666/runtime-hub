# TASK: Phase 4B — Integration Tests + Workflow Resilience

**From:** bigllm | **To:** windsurf ide ai
**Priority:** HIGH
**Phase 4A status:** Complete ✅ — clean work, well done

---

## CONTEXT

The unit tests are solid (70/70). But we have no tests that run a real workflow end-to-end through the full stack. We also have no error recovery — if a node fails mid-workflow, the whole thing just dies. This phase fixes both.

---

## PART 1 — End-to-end integration tests

Create `tests/integration/workflow-e2e.test.js`.

These tests must start a real server, execute real workflows via the API, and verify the results. No mocking the engine or server — this is the real thing.

Write tests for these 6 scenarios:

1. **Happy path** — POST a 3-node workflow (start → transform → log), verify it completes, check output matches expected
2. **Logger plugin e2e** — execute a workflow that uses the logger plugin node, verify log entries were created and are accessible via the API
3. **Data transform e2e** — execute a workflow using the data-transform plugin with uppercase operation, verify output
4. **Concurrent workflows** — start 3 workflows simultaneously, verify all complete without interfering with each other
5. **Workflow status polling** — start a workflow, poll `/api/workflows/:id/status` until complete, verify status transitions (running → completed)
6. **Stop a running workflow** — start a long workflow, call the stop endpoint mid-execution, verify it actually stops

Setup: spin up the server in `beforeAll`, tear it down in `afterAll` — no open handle issues.

---

## PART 2 — Workflow error recovery

Right now if a node throws an error mid-workflow, the workflow dies with no recovery options. Add:

### 2A — Node-level error handling config
Add an optional `onError` field to node config in the workflow JSON:
- `"onError": "stop"` — current behaviour, stops the workflow (default)
- `"onError": "skip"` — skip this node and continue to the next
- `"onError": "retry"` — retry the node up to 3 times before stopping

Implement this in `src/workflow-engine.js` / `src/engine/node-adapters.js`.

### 2B — Workflow error state in API
When a workflow errors, the status endpoint should return:
```json
{
  "status": "failed",
  "failedNode": "node-id-here",
  "error": "human readable error message",
  "completedNodes": ["node1", "node2"]
}
```
So callers know exactly where and why it failed.

### 2C — Tests for error recovery
Add at least 4 unit tests in `tests/unit/workflow-engine/` for the new error handling:
- `onError: skip` continues past a failing node
- `onError: retry` retries 3 times then fails
- `onError: stop` stops at the first failure (existing behaviour, now explicit)
- Failed workflow status includes correct node and error details

---

## PART 3 — Workflow history cleanup

The audit flagged: workflow history has a 1000-entry limit but no cleanup mechanism. Old entries just pile up. Add:

- Auto-prune history when it exceeds 500 entries — keep the 500 most recent
- Add a `DELETE /api/workflows/history` endpoint to manually clear history
- Add 2 unit tests: auto-prune triggers at 500, manual clear endpoint works

---

## PART 4 — Push to GitHub and verify CI

After all the above is done:
- Commit everything with clear commit messages
- Push to master
- Confirm CI run passes at https://github.com/gainey666/runtime-hub/actions
- Report the Actions run URL

---

## 📤 REPORT BACK

File: `guides back/DONE_2026-02-23_PHASE4B-COMPLETE.md`

Include:
1. Integration test results (all 6 scenarios passing)
2. Error recovery — confirm all 3 onError modes work with test results
3. Workflow history cleanup confirmed
4. CI green — Actions run URL
5. All git commit hashes
