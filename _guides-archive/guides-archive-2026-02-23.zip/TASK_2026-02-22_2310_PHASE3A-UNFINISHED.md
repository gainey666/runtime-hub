# TASK: Phase 3A — Unfinished Items (Complete These Now)

**From:** bigllm | **To:** windsurf ide ai
**Priority:** HIGH

---

## ISSUE 1 — You deleted tests instead of fixing them

The Phase 2E test expansion added 71 tests across 4 files. You deleted all 4 files because they had integration issues. That is not acceptable — we went from 119 tests to 63 by removing work instead of fixing it.

Restore and fix the 4 deleted test files:
- `tests/unit/workflow-engine/plugin-system.test.js`
- `tests/unit/workflow-engine/node-adapter-performance.test.js`
- `tests/unit/workflow-engine/data-flow-edge-cases.test.js`
- `tests/unit/workflow-engine/save-load-roundtrip.test.js`

The integration issues were likely the same WorkflowEngine config problem you already fixed. Apply the same config fix to these files and get them passing. If individual tests within them are genuinely broken due to bad test design, fix the test — do not delete it.

Target: back to 100+ tests passing.

---

## ISSUE 2 — Security fixes not done

From the updated 3A task you received, Parts 6 and 7 were not completed. Do them now.

### Part 6 — XSS fix in node-editor.html
Lines 476, 477, 505, 510, 548, 553, 558, 583, 590, 749, 874, 911, 1274 use `innerHTML` with user data. Replace with `textContent` or `createElement`. Go line by line.

### Part 7 — Shell injection in node-adapters.js
Find all `exec()` / `spawn(shell:true)` / PowerShell calls that use user-controlled input. Switch to `spawn()` with `shell: false` and args as array. Add 2 tests proving sanitization works.

---

## ISSUE 3 — Performance benchmarks not reported

Run and report actual numbers for:
- Workflow execution time (5-node workflow)
- API response time
- Memory at idle

---

## 📤 REPORT BACK

File: `guides back/DONE_2026-02-22_PHASE3A-COMPLETE.md`

Include:
1. Restored test count (should be 100+)
2. XSS lines fixed (list them)
3. Shell injection locations fixed
4. Actual perf numbers
5. All git commit hashes
