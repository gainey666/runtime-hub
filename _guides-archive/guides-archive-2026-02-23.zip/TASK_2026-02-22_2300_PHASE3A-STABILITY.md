# TASK: Phase 3A — Full Stability Pass (Tests, CI Green, Performance)

**From:** bigllm | **To:** windsurf ide ai
**Priority:** HIGH
**Estimated work:** Large task, take your time and do it right

---

## CONTEXT

Phase 2 is complete. Before adding more features we need the foundation solid. This task covers everything needed to get the project into a truly stable, shippable state. Do all parts before reporting back.

---

## PART 1 — Fix the 15 failing workflow engine tests

Run `npm test` and get the exact failure list. These were passing (31/31) before Phase 2 work started. Find what changed and fix it. Do NOT skip, comment out, or raise timeouts arbitrarily.

Common causes to check:
- Plugin loader being required at engine startup may be interfering with test setup
- Engine constructor changes from the Phase 2D plugin integration
- Async teardown issues leaving open handles between tests

Target: `npm test` passes **100%** — all workflow engine tests green.

---

## PART 2 — AutoClicker tests: SKIP

AutoClicker is being moved to its own separate project. Do not touch AutoClicker tests or code at all. Leave `npm run test:autoclicker` as-is. Focus only on workflow engine tests in Part 1.

---

## PART 3 — Get CI green

Push to master and confirm the GitHub Actions CI run passes. Check at: https://github.com/gainey666/runtime-hub/actions

If CI fails for any reason (missing dependency, env issue, etc.) fix it until the pipeline is green. Report the Actions run URL in your response.

---

## PART 4 — Performance benchmarks vs targets

From the project spec, these are the performance targets. Measure and report actual numbers:

| Metric | Target | How to measure |
|--------|--------|----------------|
| Workflow execution | <30ms | Time a 5-node workflow end-to-end |
| Node adapter per executor | <5ms | Already in test suite from Phase 2E |
| API response time | <20ms | Time a REST call to /api/workflows |
| Memory at idle | <150MB | Check process memory after startup |

If any metric misses its target, investigate and optimize. Report actual numbers whether they pass or fail — do not fabricate results.

---

## PART 5 — Responsive layout verification

The Phase 2C responsive layout (fe65c63) used the same clamp() approach that broke the GUI twice. Before closing this task:
- Launch the app
- Resize the window between 1024px wide and fullscreen
- Confirm nothing breaks, shifts, or gets cut off at any size
- If there are issues, fix them now while you're in this stability pass

---

## PART 6 — Security Fix: XSS in node-editor.html

A codebase audit (run separately) flagged **13 lines** in `public/node-editor.html` using `innerHTML` with user-controlled data. This is an XSS risk — if a malicious workflow file is imported, it could execute arbitrary scripts.

**Lines to fix:** 476, 477, 505, 510, 548, 553, 558, 583, 590, 749, 874, 911, 1274

**The fix is simple — replace pattern:**
```javascript
// BEFORE (unsafe)
element.innerHTML = userValue;

// AFTER (safe)
element.textContent = userValue;
```

Only use `textContent` for plain text values. If any of those lines genuinely need to render HTML structure (not user data), use `createElement` + `appendChild` instead. Go line by line and make the right call for each one.

---

## PART 7 — Security Fix: Shell Injection in node-adapters.js

The audit flagged process execution nodes in `src/engine/node-adapters.js` that pass user-controlled input into shell commands without sanitization. If a user imports a malicious workflow file, this could run arbitrary commands on their machine.

**Find all locations where user input flows into:**
- `child_process.exec()` or `execSync()`
- `child_process.spawn()` with shell: true
- PowerShell execution strings
- Any string template literals building shell commands

**Fix by:**
1. Prefer `spawn()` with `shell: false` and arguments as an array — this prevents shell interpretation entirely
2. If exec/shell is unavoidable, sanitize input: strip shell metacharacters (`; | & $ > < \` ( )`) before use
3. Add a comment above each fixed location explaining what was vulnerable and what the fix does

Add at least 2 unit tests that verify sanitization works (e.g. a command param containing `; rm -rf` should not execute the second command).

---

## 📤 REPORT BACK

File: `guides back/DONE_2026-02-22_PHASE3A-STABILITY.md`

Include:
1. Workflow engine test result (x/x passing)
2. AutoClicker test result after mock fix
3. CI run result + Actions URL
4. Actual perf numbers for all 4 metrics
5. Responsive layout status (working / fixed / issues found)
6. XSS fix — list of lines changed and approach used
7. Shell injection fix — locations found and how each was fixed
8. All git commit hashes made during this task
