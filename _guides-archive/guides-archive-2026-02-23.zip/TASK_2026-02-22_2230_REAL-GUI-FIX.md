# TASK: REAL GUI Fix — Revert 2ee831c CSS (The Actual Culprit)

**From:** bigllm | **To:** windsurf ide ai
**Priority:** CRITICAL — this is the actual root cause, not 29feab8

---

## WHAT BIGLLM FOUND

bigllm checked the full git log with timestamps. The real culprit is:

**Commit `2ee831c` — "fix: Responsive layout for all monitor sizes" (10:17am Feb 22)**

This commit added to `public/node-editor.html`:
- `position: fixed` on body with `width: 100vw; height: 100vh` — **this is what pushed everything right**
- CSS custom properties with `clamp()` for toolbar/palette sizing — **this broke the colors and spacing**
- Multiple media queries

We reverted `29feab8` (the evening responsive commit) but `2ee831c` was **never reverted** and all commits after it sat on top of the broken layout.

---

## THE FIX

### Step 1 — Restore node-editor.html to pre-2ee831c state
```bash
git checkout ae37fa4 -- public/node-editor.html
```
`ae37fa4` is the last commit that touched node-editor.html BEFORE `2ee831c`. This restores the correct CSS/layout.

### Step 2 — Re-apply ONLY the functional JS changes from later commits
After restoring, you need to manually re-add the non-CSS improvements that were added after `2ee831c`. Check these two commits for JS-only changes to node-editor.html:

```bash
git show 3d5868a -- public/node-editor.html   # save/load dialogs
git show 83b368a -- public/node-editor.html   # connection line JS fix
```

Re-apply ONLY the JavaScript portions (save/load button handlers, connection coordinate logic). Do NOT re-apply any CSS from those commits.

### Step 3 — Verify
- Launch the app — confirm colors and layout look correct (nothing pushed right)
- Confirm save/load buttons still work
- Run `npm test`
- Commit with message: `fix: Restore correct GUI layout - revert 2ee831c responsive CSS`

---

## ⚠️ DO NOT

- Do NOT revert 2ee831c with `git revert` (it will conflict with everything on top)
- Do NOT add any new responsive CSS — Phase 2C will redo this properly later
- Do NOT touch any files outside of `public/node-editor.html`

---

## 📤 REPORT BACK

File: `guides back/DONE_2026-02-22_REAL-GUI-FIX.md`
Include:
1. Confirm visual fix (colors right, nothing pushed right)
2. Which JS changes you re-applied from 3d5868a / 83b368a
3. Test results
4. Git commit hash
