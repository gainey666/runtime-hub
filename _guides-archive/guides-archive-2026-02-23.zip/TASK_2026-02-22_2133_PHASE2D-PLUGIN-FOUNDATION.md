# TASK: Phase 2D — Plugin System Foundation

**From:** bigllm | **To:** windsurf ide ai
**Priority:** HIGH
**Do this AFTER:** PHASE2C-RESPONSIVE-LAYOUT is complete and committed

---

## 🎯 OBJECTIVE

Lay the foundation for a plugin system using the existing modular architecture as the template. Plugins should be able to add new node types to the workflow engine without modifying core files.

---

## 📋 ACCEPTANCE CRITERIA

### Plugin Interface
- [ ] Define a `PluginManifest` interface (name, version, nodes[])
- [ ] Create `src/engine/plugin-loader.js` — loads plugins from a `plugins/` directory
- [ ] Each plugin exports: node type name, port definition (follows `ports.js` pattern), executor function (follows `node-adapters.js` pattern)
- [ ] Plugin loader registers new node types into the engine at startup

### Example Plugin
- [ ] Create `plugins/example-plugin/index.js` — a simple "Hello World" node type
- [ ] Example plugin adds one node type that takes a string input and outputs a greeting
- [ ] The new node type appears in the node editor's node palette

### Tests
- [ ] Add at least 3 unit tests for plugin-loader.js
- [ ] 31/31 existing tests still pass + new plugin tests pass

---

## 🔍 WHERE TO LOOK

```
src/engine/ports.js           ← port definition pattern to follow
src/engine/node-adapters.js  ← executor function pattern to follow
src/workflow-engine.js        ← where to hook plugin registration
src/server.js                 ← may need plugin init at startup
```

---

## ⚠️ CONSTRAINTS

- Plugin loader must be non-breaking — if `plugins/` dir is empty or missing, engine starts normally
- Do not modify `ports.js` or `node-adapters.js` core content — extend, don't edit
- Keep the example plugin minimal

---

## 📤 REPORT BACK

File: `guides back/DONE_2026-02-22_PHASE2D-PLUGIN-FOUNDATION.md`
Include: files changed/created, architecture summary (3-4 sentences), test results (existing + new), git commit hash.
Blocker? → `guides back/BLOCKED_2026-02-22_PHASE2D-PLUGIN-FOUNDATION.md`
