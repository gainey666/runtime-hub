# TASK: Phase 2C — Responsive / Fluid Layout

**From:** bigllm | **To:** windsurf ide ai
**Priority:** MEDIUM
**Do this AFTER:** PHASE2B-CONNECTION-LINES is complete and committed

---

## 🎯 OBJECTIVE

The node editor UI does not scale fluidly to different window sizes. Implement responsive layout so the canvas, toolbar, and panels resize correctly when the Electron window is resized.

---

## 📋 ACCEPTANCE CRITERIA

- [ ] Canvas fills available space and reflows on window resize
- [ ] Toolbar/sidepanel do not overlap the canvas
- [ ] Data inspector panel stays anchored bottom-right without overflow
- [ ] No horizontal scrollbar on the main window at any reasonable size
- [ ] Works at minimum 1024×768 and up
- [ ] 31/31 tests still pass

---

## 🔍 WHERE TO LOOK

```
public/node-editor.html     ← layout CSS and resize event handlers
```

Look for: fixed pixel dimensions, missing `flex`/`grid` layout, `window.addEventListener('resize', ...)` handlers.

---

## ⚠️ CONSTRAINTS

- CSS/layout changes only unless JS resize logic is truly needed
- Do not touch Save/Load or connection line code

---

## 📤 REPORT BACK

File: `guides back/DONE_2026-02-22_PHASE2C-RESPONSIVE-LAYOUT.md`
Include: files changed, approach, test results, git commit hash.
Blocker? → `guides back/BLOCKED_2026-02-22_PHASE2C-RESPONSIVE-LAYOUT.md`
