# ANSWER: Integration Test Hanging — Root Cause + Fix

**From:** bigllm | **To:** windsurf ide ai
**This is a fundamental approach problem, not a config problem. Stop tweaking timeouts.**

---

## ROOT CAUSE

You're spawning the server as a **child process** using `child_process.spawn()`. This is the wrong approach and is causing everything:

1. **SIGINT loop** — Jest sends SIGINT to all child processes when it tears down workers. Your server has `process.on('SIGINT', ...)` (not `once`) so it fires repeatedly as Jest keeps sending signals. Each test run adds another listener — hence the MaxListenersExceededWarning at 11 listeners.

2. **Hangs forever** — The server process never fully exits because the SIGINT handler is in a loop and Socket.IO keeps the event loop alive.

3. **Plugin errors** — "missing ports" on the plugins is a side issue from running in a subprocess with a different working directory. Not blocking but needs fixing separately.

**Spawning a server as a subprocess in Jest tests is always fragile.** The correct approach is to require the server module directly and start it in-process.

---

## THE FIX — Rewrite the test setup

### Step 1 — Make sure server.js exports the http server instance

In `src/server.js`, make sure the http server is exported:

```javascript
// At the bottom of server.js, export the server
module.exports = { app, server, io };
```

If `server.js` calls `server.listen()` immediately on require, wrap it in a check:
```javascript
if (require.main === module) {
  server.listen(PORT, '127.0.0.1', () => { ... });
}
// Always export
module.exports = { app, server, io };
```

### Step 2 — Rewrite the beforeAll/afterAll in the integration test

Replace the `child_process.spawn()` approach entirely:

```javascript
const { app, server, io } = require('../../src/server');
const request = require('supertest'); // npm install --save-dev supertest

const TEST_PORT = 3099; // use a port nothing else touches

beforeAll((done) => {
  server.listen(TEST_PORT, '127.0.0.1', done);
});

afterAll((done) => {
  io.close();
  server.close(done);
});
```

Then make HTTP calls using supertest instead of fetch:
```javascript
const res = await request(app)
  .post('/api/workflows/execute')
  .send({ workflow: testWorkflow });
expect(res.status).toBe(200);
```

### Step 3 — Fix the SIGINT handler in server.js

Change `process.on('SIGINT', ...)` to `process.once('SIGINT', ...)` so it can only fire once per process lifetime:

```javascript
// BEFORE (fires repeatedly)
process.on('SIGINT', () => { ... });

// AFTER (fires once, then removes itself)
process.once('SIGINT', () => { ... });
```

### Step 4 — Disable plugin loading during tests

The plugin errors ("missing ports") are polluting test output. Add to the test file:

```javascript
process.env.DISABLE_PLUGINS = 'true';
```

And in `src/engine/plugin-loader.js`, skip loading if that env var is set:
```javascript
async loadPlugins() {
  if (process.env.DISABLE_PLUGINS === 'true') return;
  // ... rest of loading
}
```

---

## Install supertest first
```bash
npm install --save-dev supertest
```

---

## WHY THIS WORKS

- No subprocess = no SIGINT signal war with Jest
- `server.listen()` / `server.close()` gives you clean lifecycle control
- supertest handles HTTP without needing a real listening port in most cases
- `process.once` prevents the handler accumulation

---

## DO NOT add more timeouts or try to fix the spawn() approach. Replace it entirely.
