# TASK: Phase 3B — Plugin Expansion + Full Documentation

**From:** bigllm | **To:** windsurf ide ai
**Priority:** HIGH
**Do this AFTER:** Phase 3A is complete and committed
**Estimated work:** Large task, take your time and do it right

---

## CONTEXT

Plugin system foundation exists (plugin-loader.js + hello-world example). Now we expand it into something actually useful and document the entire project properly so any developer can pick it up cold.

---

## PART 1 — Build 2 more useful example plugins

The Hello World plugin proves the system works. Now build plugins that demonstrate real value. Create both of these:

### Plugin: `plugins/logger-plugin/`
A workflow node that logs data with formatting:
- Input: accepts any data type
- Behavior: formats it as a timestamped log entry
- Output: passes the data through unchanged (passthrough pattern)
- Config: log level (info/warn/error), optional prefix label
- This teaches the passthrough pattern which will be common in real plugins

### Plugin: `plugins/data-transform-plugin/`
A workflow node that transforms data:
- Input: accepts a string or number
- Config options: uppercase, lowercase, trim, parse-as-number, parse-as-json
- Output: the transformed value
- Error handling: if transform fails (e.g. parse-as-json on invalid string), output an error object with the original value and error message
- This teaches input validation and error output patterns

Both plugins must:
- Follow the exact same manifest structure as the existing hello-world plugin
- Appear in the node editor palette when the app starts
- Execute correctly when used in a workflow
- Have at least 3 unit tests each in `tests/unit/`

---

## PART 2 — Plugin developer documentation

Create `public-docs/PLUGIN-DEVELOPMENT.md` — a complete guide for someone who wants to write their own plugin. Include:

1. **What a plugin is** — 2-3 sentences, plain English
2. **File structure** — the exact directory layout with explanation of each file
3. **Plugin manifest** — every field explained with types and whether required/optional
4. **Port definitions** — how to define inputs and outputs, what types are supported
5. **Executor function** — signature, what inputs look like, how to return outputs, how to signal errors
6. **Step-by-step tutorial** — walk through creating a new plugin from scratch using the logger-plugin as the example
7. **Testing your plugin** — how to write tests, how to run them
8. **Troubleshooting** — top 5 things that go wrong when writing a plugin

---

## PART 3 — Update public-docs for new architecture

The `public-docs/` folder has documentation that predates the Phase 2 refactor. Update it to reflect current reality:

- Update any references to the old monolithic `workflow-engine.js` to explain the new `engine/ports.js` + `engine/node-adapters.js` split
- Add a section on the plugin system to the main README or architecture doc
- Update node count (was 28, now 33+ with plugins)
- Make sure the quick-start guide still works with the current codebase

Do not rewrite docs that are still accurate — only update what's wrong or missing.

---

## PART 4 — API documentation

Create `public-docs/API-REFERENCE.md` covering the REST endpoints in `src/server.js`:

For each endpoint document:
- Method + path
- Description (one line)
- Request body (if any) with field types
- Response format with example
- Error responses

At minimum cover: workflow CRUD endpoints, execution endpoints, any plugin-related endpoints added in Phase 2D.

---

## 📤 REPORT BACK

File: `guides back/DONE_2026-02-22_PHASE3B-PLUGINS-DOCS.md`

Include:
1. Both new plugins confirmed working in the app (with node types that appear in palette)
2. Test results for new plugin tests
3. List of docs files created/updated
4. Any gaps found in existing docs that were fixed
5. All git commit hashes
