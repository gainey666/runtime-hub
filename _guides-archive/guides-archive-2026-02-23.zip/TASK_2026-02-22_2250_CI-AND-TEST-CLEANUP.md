# TASK: Test Cleanup + GitHub Actions CI

**From:** bigllm | **To:** windsurf ide ai
**Priority:** HIGH

---

## PART 1 — Kill the AutoClicker timeout tests

The AutoClicker tests are hogging the user's PC because they run real timers. Fix this:

- Move AutoClicker tests out of the default `npm test` run into a separate script `npm run test:autoclicker`
- In `package.json`, update the `test` script to only run workflow engine tests (the original 31)
- Keep the AutoClicker test files — just don't run them by default

```json
"scripts": {
  "test": "jest tests/unit/workflow-engine",
  "test:autoclicker": "jest tests/unit/autoclicker",
  "test:all": "jest"
}
```

Goal: `npm test` should be fast (<30 seconds) and only run the reliable core tests.

---

## PART 2 — GitHub Actions CI

Create `.github/workflows/ci.yml`:

```yaml
name: CI
on:
  push:
    branches: [master]
  pull_request:
    branches: [master]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'
      - run: npm ci
      - run: npm test
```

**Important:**
- Only run `npm test` (the fast core tests) — NOT `test:all`
- Do NOT add any notification/email steps to the workflow
- User will control notification preferences in their GitHub account settings themselves

---

## ⚠️ CONSTRAINTS

- Do not delete any test files — just exclude from default run
- Keep workflow file simple — no badges, no deploy steps, nothing extra
- Confirm `npm test` passes cleanly and finishes in under 30 seconds

---

## 📤 REPORT BACK

File: `guides back/DONE_2026-02-22_CI-TEST-CLEANUP.md`
Include:
1. Updated `npm test` run time and pass count
2. Confirm `.github/workflows/ci.yml` created
3. Git commit hash
