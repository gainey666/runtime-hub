# ⛔ DO NOT RUN — AUDIT TASK (STANDBY ONLY)

**From:** bigllm | **To:** audit windsurf ai (second terminal)
**Status:** STANDBY — do NOT execute until user explicitly says "run the audit"

---

## ⛔ IMPORTANT — READ FIRST

This file is for a **separate** Windsurf AI instance in its own terminal.

- If you are the **primary Windsurf AI** working on Phase 3A or 3B — **ignore this file completely and do not touch it**
- If you are the **audit Windsurf AI** in the second terminal — wait for the user to explicitly tell you to run this before doing anything
- Do not begin until the user says words to the effect of **"run the audit"**

---

## 🎯 OBJECTIVE

When instructed to run: perform a full read-only audit of the Runtime Hub codebase and write findings to `guides back/`. Do not modify any code. Read only.

---

## AUDIT SCOPE

Work through each area below. Write everything to a single report file at the end.

### 1. Architecture health
- Read `src/workflow-engine.js`, `src/engine/ports.js`, `src/engine/node-adapters.js`, `src/engine/plugin-loader.js`
- Are responsibilities cleanly separated? Any obvious bloat or overlap?
- Does plugin-loader integrate cleanly or does it feel bolted on?

### 2. Dead code + unused files
- Scan for files that are imported nowhere
- Look for commented-out blocks of 10+ lines
- Check `tools/`, `patches/`, `codemods/`, `type_tests/` — are these still relevant?

### 3. Security surface
- `src/server.js` — any endpoints with no input validation? Any shell execution with unsanitized input?
- `public/node-editor.html` — any `innerHTML` assignments using user data (XSS risk)?
- Plugin loader — can a malicious plugin escape the sandbox?

### 4. Test quality
- Read through `tests/unit/workflow-engine/` — are the new Phase 2E tests actually meaningful or are they testing mocks of mocks?
- Are the 15 failing tests a symptom of bad tests or real bugs?
- Is there anything completely untested that should be?

### 5. Performance risks
- Any synchronous file I/O on the hot path in server.js or workflow-engine.js?
- Any unbounded loops or missing pagination on data that could grow?
- Memory leaks — are event listeners cleaned up? Are workflow instances destroyed after completion?

### 6. Plugin system robustness
- Can a plugin crash the whole engine? Is there error isolation?
- What happens if a plugin takes 10 seconds to execute — does it block everything?
- Are plugins loaded fresh each restart or cached in a way that could cause stale state?

### 7. Overall code consistency
- Are there files still using old patterns from before the Phase 2 refactor?
- Mixed async styles (callbacks vs promises vs async/await)?
- Any hardcoded paths or magic numbers that should be config?

---

## 📤 REPORT BACK

Write a single file: `guides back/AUDIT_2026-02-22_CODEBASE.md`

Structure it as:
- **GREEN** — things that are solid, no action needed
- **YELLOW** — things that are weak but not urgent (tech debt)
- **RED** — things that need fixing before this project goes further

Keep it concise. bigllm will read this and decide what to action. Do not write more than needed.

Do NOT commit anything. Read only.
