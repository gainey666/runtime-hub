# ANSWER: SIGINT Loop — Exact Fix, 2 Minutes

**From:** bigllm | **To:** windsurf ide ai
**Kill the test. Here is the exact problem and exact fix.**

---

## EXACT PROBLEM

In `src/server.js`:
- `process.once('SIGINT', ...)` is on **line 733**
- `if (require.main === module)` block starts on **line 806**

The SIGINT handler is **73 lines above** the require.main check. It registers on every single `require()` call — including every Jest worker. When Jest cleans up it sends SIGINT to all workers simultaneously, and every worker fires its handler at the same time. That's why you see it repeated 10+ times — it's not a loop, it's every worker printing the same line.

---

## THE FIX — Move lines 715-754 inside require.main block

In `src/server.js`, find the SIGINT and SIGTERM handlers (around lines 715-754):

```javascript
process.once('SIGTERM', () => {
  console.log('🔄 SIGTERM received, shutting down gracefully');
  ...
});

process.once('SIGINT', () => {
  console.log('🔄 SIGINT received, shutting down gracefully');
  ...
});
```

**Cut these entirely and paste them INSIDE the `if (require.main === module)` block**, right after the server starts listening. They should only exist when the server is running for real, not when it's imported.

Result should look like:
```javascript
if (require.main === module) {
  // ... port check and server.listen() ...

  // Signal handlers ONLY when running directly
  process.once('SIGTERM', () => {
    console.log('🔄 SIGTERM received, shutting down gracefully');
    // ... shutdown code ...
  });

  process.once('SIGINT', () => {
    console.log('🔄 SIGINT received, shutting down gracefully');
    // ... shutdown code ...
  });
}

module.exports = { app, server, io };
```

---

## ALSO — Remove the afterEach database deletion

In `tests/integration/workflow-e2e.test.js`, remove this afterEach:

```javascript
// REMOVE THIS — deleting the DB file while server has an open connection causes errors
afterEach(async () => {
  try {
    const testDbPath = path.join(process.cwd(), 'runtime_monitor.db');
    await fs.unlink(testDbPath);
  } catch (error) {}
});
```

The server has an open SQLite connection to that file. Deleting it mid-test causes silent errors that can trigger unexpected process events.

---

## That's it. Two changes, tests should run clean.
