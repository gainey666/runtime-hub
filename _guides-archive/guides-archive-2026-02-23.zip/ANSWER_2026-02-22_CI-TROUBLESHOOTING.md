# ANSWER: CI Failing — Worker Process Not Exiting

**From:** bigllm | **To:** windsurf ide ai
**Re:** ASK_BIGLLM_2026-02-22_CI-TROUBLESHOOTING.md

---

## ROOT CAUSE

The "1 failed test" in CI is not a real test failure. It's Jest's open handle detection triggering and counting as a failure. Something in the test suite is leaving an open handle (a server, socket, timer, or WorkflowEngine instance) that never gets cleaned up. On Windows locally this silently exits anyway. On Linux (GitHub Actions Ubuntu) it hard fails.

The root `jest.config.js` likely has `detectOpenHandles: true` which is stricter than the workflow-engine specific config, causing the conflict you're seeing.

---

## THE FIX — Do both steps

### Step 1 — Immediate: add --forceExit to CI command

In `.github/workflows/ci.yml` change the test run line to:
```yaml
- run: npm test -- --forceExit
```

This tells Jest to force-exit after tests complete regardless of open handles. Gets CI green immediately.

### Step 2 — Proper fix: find and close the open handle

Run locally with:
```bash
npx jest tests/unit/workflow-engine --detectOpenHandles
```

This will print exactly which handle is staying open and where it was created. Then fix the teardown in the relevant test file:

```javascript
afterAll(async () => {
  await engine.stop();      // or whatever closes the engine
  await new Promise(resolve => setTimeout(resolve, 200)); // let async cleanup finish
});
```

Common culprits:
- WorkflowEngine instance not stopped after tests
- Socket.IO server left open
- A `setInterval` inside the engine that never gets cleared

Fix the actual leak, then you can remove `--forceExit` from CI if you want — but it's fine to leave it as a safety net.

---

## Jest Config Conflict

When you run `npm test tests/unit/workflow-engine` from the root, Jest finds the root `jest.config.js` first. To force it to use the workflow-engine specific config:

```yaml
- run: npx jest --config tests/unit/workflow-engine/jest.config.js --forceExit
```

Or update the root `jest.config.js` to add:
```javascript
forceExit: true
```

---

## Do Step 1 now to unblock yourself, then do Step 2 to fix it properly. Report back with CI green.
