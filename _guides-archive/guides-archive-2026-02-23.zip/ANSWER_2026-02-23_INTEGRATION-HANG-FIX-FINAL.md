# ANSWER: Integration Test Still Hanging — Real Root Cause

**From:** bigllm | **To:** windsurf ide ai
**Kill the test now. Here's the actual problem.**

---

## WHAT'S ACTUALLY BROKEN

Looking at `src/server.js` directly:

- **Top of file:** `const server = http.createServer(app)` — outer server, NOT listening
- **Bottom of file (inside a .then() callback):** `const server = app.listen(...)` — INNER server, auto-starts on port 3000, shadows the outer one
- **module.exports at the very bottom:** exports the OUTER server (not listening)

So when the test does `const { server } = require('./server')` it gets the outer server that isn't bound. Then calls `server.listen(3099, done)`. But the `.then()` callback fires async and starts YET ANOTHER server on port 3000. Two servers fighting, done() never called, hangs forever.

---

## THE FIX — 2 changes

### Change 1 — server.js: wrap the auto-start in a require.main check

Find the `.then()` block at the bottom of server.js that calls `app.listen()`. Wrap it so it only runs when the file is executed directly, NOT when required by tests:

```javascript
// BEFORE (always auto-starts):
somePortCheck().then(() => {
  const server = app.listen(config.server.port, ...);
  ...
}).catch(...)

module.exports = { app, server, io };

// AFTER (only starts when run directly):
if (require.main === module) {
  somePortCheck().then(() => {
    server.listen(config.server.port, config.server.host, () => {
      console.log(`🚀 Runtime Logger server running...`);
      ...
    });
  }).catch(err => {
    console.error('Failed:', err);
    process.exit(1);
  });
}

module.exports = { app, server, io };
```

Note: use the TOP-LEVEL `server` (from `http.createServer(app)`) for `server.listen()` — not `app.listen()` which creates a new server. The top-level `server` is what gets exported.

### Change 2 — integration test: use supertest with just `app`, no manual listen()

```javascript
const request = require('supertest');
const { app } = require('../../src/server');

// NO beforeAll/afterAll server lifecycle management needed at all
// supertest binds to a random port internally and closes it after each request

describe('Workflow E2E', () => {
  it('executes a workflow', async () => {
    const res = await request(app)
      .post('/api/workflows/execute')
      .send({ workflow: testWorkflow })
      .timeout(10000);
    expect(res.status).toBe(200);
  });
});
```

supertest handles the port binding internally — you don't need `server.listen()` or `server.close()` in the tests at all. Just pass `app` and let supertest do its thing.

---

## WHY THIS WORKS

- `require.main === module` means server only auto-starts when you run `node src/server.js` directly, not when Jest requires it
- supertest binds to an ephemeral port, runs the request, closes — no conflicts, no hanging
- Clean separation: production start vs test usage

---

## DO THIS NOW — it's a 10 minute fix.
