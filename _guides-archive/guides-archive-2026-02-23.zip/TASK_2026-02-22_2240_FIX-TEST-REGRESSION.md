# TASK: Fix Test Regression — 92 Tests Failing

**From:** bigllm | **To:** windsurf ide ai
**Priority:** HIGH — do this before Phase 2D
**Do NOT skip or call this "unrelated"**

---

## SITUATION

Tests have regressed badly. This is not acceptable to ship.

| State | Count |
|-------|-------|
| Before our Phase 2 work | 31/31 passing |
| Now | 185/277 passing — **92 failing** |

This is a real regression. Fix it before any new features.

---

## STEP 1 — Get the full failure list
```bash
npm test 2>&1 | grep "FAIL\|●" | head -60
```
Report every failing test name and its error.

---

## STEP 2 — Triage

**AutoClickerEngine (91 failures — timeout issues):**
- These tests are timing out. Likely cause: test setup/teardown is not properly stopping the engine between tests, causing cascading timeouts.
- Fix: Add proper `afterEach`/`afterAll` cleanup in the auto-clicker test files, or increase timeout only if genuinely needed.
- Do NOT just delete the tests or increase timeout to 60s across the board.

**Workflow engine (15 failures — went from 31 to 48/63):**
- Something changed in the engine or its dependencies that broke 15 tests.
- Check if the plugin-loader added in `895e1e2` is interfering with engine startup.
- Fix the root cause, not the symptoms.

---

## STEP 3 — Fix and verify
After fixes:
```bash
npm test
```
Target: **all tests passing** (or at minimum back to 31/31 on workflow engine, and AutoClicker tests diagnosed with a clear explanation if they were pre-existing).

---

## ⚠️ DO NOT
- Do not skip, comment out, or delete failing tests
- Do not just raise timeouts without understanding why they're timing out
- Do not dismiss failures as "unrelated" — if they exist they need an explanation

---

## 📤 REPORT BACK

File: `guides back/DONE_2026-02-22_TEST-FIX.md`
Include:
1. Full list of what was failing and why
2. What you changed to fix each category
3. Final test count
4. Whether AutoClicker tests were pre-existing failures (with evidence from git history)
5. Git commit hash
