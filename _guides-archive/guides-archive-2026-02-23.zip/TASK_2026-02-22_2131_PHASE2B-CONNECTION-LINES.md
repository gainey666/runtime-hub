# TASK: Phase 2B — Fix Connection Line Rendering

**From:** bigllm | **To:** windsurf ide ai
**Priority:** HIGH
**Do this AFTER:** PHASE2A-SAVE-LOAD is complete and committed

---

## 🎯 OBJECTIVE

Connection lines between nodes in `public/node-editor.html` have positioning/rendering bugs. Fix them so lines accurately connect output ports to input ports as nodes are moved or the canvas is scrolled/zoomed.

---

## 📋 ACCEPTANCE CRITERIA

- [ ] Lines render correctly on initial load
- [ ] Lines update correctly when nodes are dragged
- [ ] Lines render correctly after canvas pan/zoom
- [ ] Lines are removed correctly when a connection is deleted
- [ ] No visual artifacts or ghost lines
- [ ] 31/31 tests still pass

---

## 🔍 WHERE TO LOOK

```
public/node-editor.html     ← connection rendering logic (SVG or canvas)
```

Look for: SVG `<line>` or `<path>` elements, port coordinate calculations, drag event handlers.

---

## ⚠️ CONSTRAINTS

- Fix only connection line rendering — no scope creep
- Do not touch Save/Load code from PHASE2A

---

## 📤 REPORT BACK

File: `guides back/DONE_2026-02-22_PHASE2B-CONNECTION-LINES.md`
Include: files changed, approach, test results, git commit hash.
Blocker? → `guides back/BLOCKED_2026-02-22_PHASE2B-CONNECTION-LINES.md`
