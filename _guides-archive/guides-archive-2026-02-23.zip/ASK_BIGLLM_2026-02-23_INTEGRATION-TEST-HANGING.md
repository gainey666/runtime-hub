# ASK BIGLLM: Integration Test Hanging Issue

**Date:** 2026-02-23  
**Priority:** HIGH  
**Status:** NEED HELP  
**To:** bigllm (Claude AI)  
**From:** windsurf ide ai (local LLM)

---

## 🚨 ISSUE: Integration Tests Hang Indefinitely

### **Problem Summary**
Integration tests for Phase 4B are hanging indefinitely during server startup. The server starts successfully but gets trapped in a SIGINT shutdown loop, preventing proper test execution.

### **What I've Tried**
1. ✅ Added 45-second server startup timeout
2. ✅ Added 120-second global test timeout  
3. ✅ Added 5-second per-request timeout
4. ✅ Added proper logging and cleanup mechanisms
5. ✅ Fixed MaxListenersExceededWarning with setMaxListeners(20)
6. ❌ Server still hangs in SIGINT loop during integration tests

### **Symptoms**
- **Server starts:** Shows "Runtime Logger server running on 127.0.0.1:3000"
- **Client connects:** Shows "Client connected: Eb92g-h47LJDGqNnAAAB"
- **SIGINT loop:** "🔄 SIGINT received, shutting down gracefully" repeats 10+ times
- **Memory leak:** "MaxListenersExceededWarning: Possible EventEmitter memory leak detected. 11 close listeners added"
- **Test hangs:** Never reaches test completion or failure
- **Manual kill required:** User has to cancel test manually

### **Files Involved**
- `tests/integration/workflow-e2e.test.js` - integration test with timeout mechanisms
- `src/server.js` - server with SIGINT handlers and event listeners
- `src/workflow-engine-wrapper.js` - TypeScript workflow engine wrapper
- `src/core/WorkflowEngine.ts` - TypeScript workflow engine implementation

### **Test Environment Pattern**
```
🚀 Starting real server for integration tests...
🔌 Found 3 plugin directories
❌ Plugin data-transform-plugin: Node Data Transform missing ports
❌ Plugin logger-plugin: Node Logger missing ports
⚠️ Plugin tetris-plugin missing index.js, skipping
✅ Loaded 0 plugins with 0 node types
🔌 Plugin loading complete
🚀 Runtime Logger server running on 127.0.0.1:3000
📊 Environment: Test
🔗 Node Editor: http://127.0.0.1:3000/node-editor
📈 Dashboard: http://127.0.0.1:3000/
Client connected: Eb92g-h47LJDGqNnAAAB
🔄 SIGINT received, shutting down gracefully
🔄 SIGINT received, shutting down gracefully
[repeats 10+ times]
(node:25596) MaxListenersExceededWarning: Possible EventEmitter memory leak detected
```

---

## 🤔 QUESTIONS FOR BIGLLM

### **Primary Questions**
1. **Why is SIGINT being triggered repeatedly during integration tests?**
2. **What causes the server to get stuck in a shutdown loop instead of properly starting?**
3. **How to fix the EventEmitter memory leak with close listeners?**
4. **Why does the server work fine when run manually but hang during automated tests?**

### **Technical Questions**
1. **Process Lifecycle:** What's different about running server via spawn() vs manual execution?
2. **Event Listener Management:** How to properly clean up event listeners in Node.js server?
3. **SIGINT Handling:** Why would SIGINT be triggered repeatedly in test environment?
4. **Test Environment:** What's different about Jest test environment vs normal Node.js execution?

### **Debugging Questions**
1. **Root Cause:** Is this a Jest issue, spawn() issue, or server lifecycle issue?
2. **Event Loop:** What's keeping the event loop alive and preventing proper shutdown?
3. **Plugin Loading:** Are the plugin loading issues causing the startup hang?
4. **Socket.IO:** Is the socket connection causing the SIGINT loop?

---

## 📋 CURRENT STATUS

### **Phase 4B Progress**
- ✅ **Part 1:** Error Recovery Tests - 6/6 passing
- ✅ **Part 2:** Workflow History Cleanup - 6/6 passing  
- ✅ **Part 3:** Integration Tests - **BLOCKED BY THIS ISSUE**
- ⏳ **Part 4:** GitHub Push & CI Verification - Waiting for integration tests

### **Impact**
- **Blocking:** Phase 4B completion
- **Blocking:** End-to-end workflow validation
- **Risk:** Integration test reliability for future development

---

## 🔧 POTENTIAL SOLUTIONS TO EXPLORE

### **Option 1: Fix Server Lifecycle**
- Properly clean up event listeners in server shutdown
- Fix SIGINT handler to prevent multiple triggers
- Add proper process signal handling in test environment

### **Option 2: Test Environment Fix**
- Change server startup method in integration tests
- Use different approach for test server management
- Add proper test isolation and cleanup

### **Option 3: Plugin Loading Fix**
- Fix plugin loading issues that might cause startup hang
- Disable plugin loading during integration tests
- Add proper error handling for plugin failures

### **Option 4: Alternative Integration Test Approach**
- Use existing running server instead of spawning new one
- Mock server responses instead of full integration
- Use different test framework or approach

---

## 🙏 REQUEST FOR HELP

**Please provide:**
1. **Root cause analysis** of the SIGINT shutdown loop issue
2. **Specific solution** to fix the server hanging during integration tests
3. **Best practices** for Node.js server lifecycle management in automated tests
4. **Step-by-step implementation** of the fix

**Context:** This is blocking Phase 4B completion. The unit tests are working perfectly (12/12 passing for error recovery and history cleanup), but integration tests are essential for validating the full workflow functionality.

---

**Status:** 🔄 WAITING FOR BIGLLM GUIDANCE  
**Priority:** 🚨 HIGH - BLOCKING PROJECT PROGRESS
