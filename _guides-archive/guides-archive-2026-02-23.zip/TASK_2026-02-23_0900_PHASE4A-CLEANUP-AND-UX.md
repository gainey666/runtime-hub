# TASK: Phase 4A — Test Cleanup + Node Editor UX Polish

**From:** bigllm | **To:** windsurf ide ai
**Priority:** HIGH
**Estimated work:** Large session

---

## MANDATORY FIRST — Fix the skipped/failing tests

The CI cleanup report shows 4 failing tests and 2 skipped ("Start Process node", "Monitor Function node"). This is the third time tests have been hidden instead of fixed. It stops now.

Run `npm test` and get the exact failure output for all 4 failing tests and the 2 skipped.

For each one:
- If it's a **timeout**: the node executor is running real async work in the test. Mock it with Jest mocks instead of running the real thing. Do NOT increase the timeout.
- If it's an **implementation bug**: fix the actual bug in the node adapter, then re-enable the test.
- If the test itself is badly written: rewrite the test to test the right thing.

Do NOT skip, comment out, or delete any test. Target: `npm test` shows 0 failing, 0 skipped.

---

## PART 2 — Dead code cleanup (from audit)

The codebase audit flagged these as yellow (tech debt). Clean them up:

1. **`patches/` directory** — 4 patch files. Check if any are still needed. If not, delete the whole directory.
2. **`codemods/` directory** — TypeScript fix scripts. Almost certainly one-time use. Delete if unused.
3. **Root-level `test-*.js` files** — temporary debug files left in the project root. List them, confirm they're not part of anything, delete them.
4. **`tools/python-mechanic/`** — audit flagged as unused. Verify and delete if confirmed.

For each one: check if anything imports or references it before deleting. If in doubt, leave it and note why.

---

## PART 3 — Node editor UX improvements

The node editor works but has rough edges. Fix these specific things in `public/node-editor.html`:

### 3A — Workflow templates
Add 3 starter templates a user can load from a "New Workflow" menu or button:
- **Blank** — empty canvas
- **Hello World** — a simple 2-node workflow (trigger → log output)
- **Data Pipeline** — a 4-node workflow showing data flowing through transform nodes

Templates should load as pre-built node graphs the user can modify.

### 3B — Better node execution feedback
Currently when a workflow runs, it's not clear what's happening. Add:
- Visual highlight on the currently-executing node (different color/border while running)
- A small success/fail indicator on each node after execution completes (green tick or red X)
- These should clear when a new workflow run starts

### 3C — Connection validation
Right now users can connect any output to any input even if the types don't match (e.g. connecting a number output to a string input). Add basic visual feedback:
- When dragging a connection, highlight compatible input ports in green and incompatible ones in red/grey
- Don't block the connection (let user override) — just inform them visually

---

## PART 4 — preload.js async pattern (from audit)

The audit flagged `preload.js` as using callback patterns while the rest of the codebase uses async/await. Convert it to async/await for consistency. Small task but worth doing while we're in a cleanup phase.

---

## 📤 REPORT BACK

File: `guides back/DONE_2026-02-23_PHASE4A-COMPLETE.md`

Include:
1. Test results — final count, 0 failing, 0 skipped confirmed
2. What each of the 4 failing / 2 skipped tests actually was and how you fixed it
3. Dead code removed (list of files/dirs deleted)
4. Screenshots or description of all 3 UX improvements working
5. preload.js conversion confirmed
6. All git commit hashes
