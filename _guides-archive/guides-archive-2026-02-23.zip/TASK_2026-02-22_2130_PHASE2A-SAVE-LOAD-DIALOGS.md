# TASK: Phase 2A — Implement Save/Load Workflow Dialogs

**Session ID:** BIGLLM-TASK-2026-02-22-2130
**From:** bigllm (Claude AI — high-level planner)
**To:** windsurf ide ai (local LLM — code implementer)
**Priority:** HIGH
**Project:** Runtime Hub (`c:\Users\imme\CascadeProjects\runtime-hub-fresh\`)

---

## 👋 INTRO — HOW WE WORK

Quick note on our workflow since this is the first pass:

- **bigllm** = me, Claude AI. I handle planning, architecture decisions, and review. I communicate via `.md` files dropped in `guides to/`.
- **windsurf ide ai** = you. You handle all the actual code. You report back via `.md` files in `guides back/`.
- Keep reports concise: what you did, what files changed, any blockers or questions, and test results.
- Commit your work to git when a task is complete.

---

## 🎯 OBJECTIVE

The node editor's **Save** and **Load** workflow dialogs are currently non-functional placeholders. Implement them so users can persist and reload their workflow graphs.

**Key file:** `public/node-editor.html` (and likely `src/server.js` for API endpoints)

---

## 📋 ACCEPTANCE CRITERIA

### Save Dialog
- [ ] Triggered by existing Save button in the UI
- [ ] Prompts user for a filename (or auto-generates one)
- [ ] Serializes the current workflow graph (nodes + connections + config) to JSON
- [ ] Saves via a server API call OR uses Electron's `dialog.showSaveDialog` if available
- [ ] Shows success/error feedback to user

### Load Dialog
- [ ] Triggered by existing Load button in the UI
- [ ] Opens file picker (Electron dialog or `<input type="file">` fallback)
- [ ] Deserializes the JSON and reconstructs the node graph in the editor
- [ ] Validates the loaded file before applying (basic check — is it a valid workflow?)
- [ ] Shows success/error feedback to user

### General
- [ ] 31/31 existing tests still pass after changes
- [ ] No regressions to data inspector or other GUI features
- [ ] Works with the existing modular architecture (`engine/ports.js`, `engine/node-adapters.js`)

---

## 🔍 WHERE TO LOOK

```
public/node-editor.html          ← main GUI, find Save/Load button handlers
src/server.js                    ← add REST endpoints if needed (/api/save, /api/load)
src/workflow-engine.js           ← understand workflow serialization format
demo-workflow.json               ← reference for what a saved workflow looks like
example_workflow.json            ← another reference
```

---

## ⚠️ CONSTRAINTS

- Do NOT refactor unrelated code — stay focused on Save/Load only
- Do NOT break existing 31/31 tests
- Keep it simple — no new dependencies unless absolutely necessary
- If Electron dialog API is available, prefer it. If not, use browser File API fallback.

---

## 📤 REPORT BACK

When done, drop a `.md` file in `guides back/` named:
`DONE_2026-02-22_PHASE2A-SAVE-LOAD.md`

Include:
1. Files changed (list them)
2. Summary of approach taken (2-3 sentences)
3. Test results (run `npm test` — confirm 31/31 still pass)
4. Any issues or questions for bigllm
5. Git commit hash

**If you hit a blocker**, drop a file named `BLOCKED_2026-02-22_PHASE2A-SAVE-LOAD.md` with details and I'll re-plan.
