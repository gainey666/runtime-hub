Chosen Integration Approach

Option A Hybrid integration (confirmed).  
Rationale: Preserve and reuse the Python overlay work for orchestration, UI, and rapid iteration while selectively leveraging native C++ components from the C++ repo for capture and any recognition hot paths that require deterministic low-latency performance. This minimizes rewrite cost, shortens time to an MVP integrated into Runtime Hub, and leaves clear upgrade paths for performance-critical modules.
Clarifying Question Responses and Notes

MVP Scope

    Status: Undecided for now. We will keep scope flexible and finalize before Phase 1 implementation. Possible MVP variants: full run_overlay_core.py feature set or a smaller detection + ghost overlay subset. Decision deferred.

Preferred Integration Host

    Decision: Integrate into Runtime Hub as a full plugin node exposing UI controls. Runtime Hub will be the orchestration surface for users.

Performance Hot Paths Education and Next Step

    User Input: Unsure which components to optimize first and asked for education.

    Short primer:

        Frame Capture is often the first bottleneck on Windows; inefficient capture or format conversion can add tens of milliseconds per frame. Native code (DirectX/Direct3D capture or Desktop Duplication API) usually yields the lowest jitter and CPU overhead.

        Piece Recognition (per-cell classification) can be either cheap (template matching, color heuristics) or expensive (CNN inference). If recognition uses a small CNN, GPU or optimized native inference (ONNX Runtime, TensorRT) reduces latency.

        Prediction Inference (longer-horizon ML models) tends to be less frequent and can be batched; heuristics often suffice for immediate coaching.

    Recommendation: Start by instrumenting the Python overlay to measure per-stage latency (capture, preprocess, recognition, prediction). Use those measurements to prioritize native optimization. I will produce a short measurement plan and then recommend which component to move to C++ first based on real data.

Data and Test Assets

    Status: You attempted to use stats.db and calibration.json but they did not work. We will treat the current repo artifacts as starting points but will create a reproducible test set of recorded gameplay clips and labeled frames for validation.

Runtime Hub Integration Level

    Decision: Full plugin node exposing UI controls. Runtime Hub will be the primary user interface and orchestration layer.

Licensing and Redistribution

    Status: You do not intend to monetize; open-source MIT is acceptable. No monetization or paid-tier recommendations will be included in planning.

Access and Scope Note

    I will only use the four GitHub repositories you specified as the canonical code sources for planning and mapping tasks.

Phase 1 Architectural Guidance
Goals for Phase 1

    Deliver a Runtime Hub plugin node that performs reliable board detection and per-piece recognition on a single board, provides intermediate coaching hints, and exposes calibration and logging controls in the Runtime Hub UI.

    Keep the implementation modular so native components can be swapped in later without changing orchestration logic.

Core Components and Responsibilities

Capture Adapter

    Role: Low-latency frame capture from the game window or full screen.

    Implementation Plan: Start with the Python capture in -tetris-overlay-test for rapid iteration. Add an abstraction layer capture_adapter that can be backed by either Python screen capture or a native C++ capture module from -tetris-overlay-cpp. Expose frames to the pipeline as a standardized format (RGBA or BGR, fixed stride, timestamp).

Preprocessing Pipeline

    Role: ROI extraction, color normalization, resizing, and optional GPU-accelerated transforms.

    Implementation Plan: Implement in Python using OpenCV and NumPy. Keep operations vectorized and batch-friendly. Provide hooks to enable GPU transforms later.

Board Detection and Calibration

    Role: Locate the playfield grid and map screen coordinates to logical cells.

    Implementation Plan: Use automatic OpenCV-based detection with a manual calibration fallback UI inside the Runtime Hub node. Persist calibration per profile.

Piece Recognition

    Role: Determine occupancy and piece type per cell.

    Implementation Plan: Start with a lightweight hybrid approach: template matching and color heuristics as fallback; a small CNN for ambiguous cases. Run recognition in Python with TorchScript/ONNX export option. If recognition latency dominates, move inference to native runtime or C++ binding.

Game State Manager

    Role: Maintain canonical board state, hold/queue, and deterministic state transitions.

    Implementation Plan: Implement as a pure-Python deterministic state machine with unit tests. Expose read-only state to UI and prediction modules.

Prediction Engine

    Role: Provide immediate move suggestions and short-term forecasts.

    Implementation Plan: Implement a heuristic-first layer for MVP (fast, interpretable). Add an ML layer for longer-horizon predictions in Phase 2. Keep model orchestration in Python; export models for native inference if needed.

Coaching Module

    Role: Generate intermediate coaching hints and move rankings.

    Implementation Plan: Start with intermediate coaching mode only. Deliver hints via Runtime Hub UI elements and optional audio cues. Respect the no-overlay constraint by using Runtime Hub’s allowed output channels.

Runtime Hub Plugin Node

    Role: Host the entire pipeline, provide calibration and control UI, and expose telemetry toggles.

    Implementation Plan: Build a Runtime Hub node that embeds the Python agent or communicates with a Python process. Provide clear configuration for capture source, calibration, recognition mode, and logging.

Telemetry and Logging

    Role: Local logs for debugging and optional opt-in telemetry for aggregated metrics.

    Implementation Plan: Default to local-only logs. Telemetry must be opt-in and anonymized.

Interfaces and Contracts

Frame Format Contract

    Format: BGR or RGBA 8-bit per channel; fixed width/height per calibration; timestamp in milliseconds since epoch; frame sequence number.

    Transfer Mechanism: Start with in-process Python objects for MVP. For native module integration, use one of:

        pybind11 binding that returns a NumPy array view without copying, or

        Shared memory ring buffer with a small header (sequence, timestamp, width, height, format) for cross-process transfers.

C++ ↔ Python Boundary Principles

    Keep the boundary minimal and well-typed. Transfer raw frames and small metadata only. Keep stateful logic in Python to avoid ABI churn. Provide a small, versioned API for capture start/stop, get frame, and calibration metadata.

Performance Targets and Testing

Latency Targets

    Per-frame recognition latency: aim for ≤ 20 ms for recognition stage on machines with a modest GPU.

    End-to-end coaching latency: aim for ≤ 50 ms from capture to coaching output for responsive UX.

Accuracy Targets

    Piece detection accuracy: target ≥ 98% on validation frames for MVP.

    Calibration success: auto-detect should succeed on ≥ 90% of test videos.

Testing Plan

    Unit tests for state manager and heuristics.

    Integration tests using recorded gameplay clips.

    Performance benchmarks for capture and recognition paths.

    CI job to run tests and benchmarks on sample data.

Success Criteria and Metrics

Technical Success Criteria

    Runtime Hub plugin node that reliably detects the board and pieces in typical gameplay scenarios.

    Intermediate coaching hints delivered within latency targets.

    Automated tests covering core state transitions and recognition logic.

Quality Metrics

    Detection accuracy ≥ 98% on validation set.

    End-to-end latency ≤ 50 ms in benchmark environment.

    Auto-calibration success ≥ 90% on test videos.

Delivery Milestones

    MVP Ready: core detection, recognition, and Runtime Hub node with intermediate coaching.

    Polish: performance tuning and packaging for Windows.

Mapping to Provided GitHub Repositories

-tetris-overlay-test

    Use as canonical Python orchestration and UI code. Map capture, preprocessing, recognition prototypes, and tests here.

-tetris-overlay-cpp

    Use as reference and source for native capture and OpenCV detection modules. Extract a capture adapter and optional recognition helpers if profiling shows capture or recognition is the bottleneck.

runtime-hub

    Implement the plugin node here. Reuse existing node patterns and Python agent integration approaches.

auto-clicker-automation

    Use patterns for robust screen capture, OCR, and multi-threaded processing as references for reliability and performance.

Immediate Action Items for the Team

    Confirm MVP Scope — finalize whether MVP is full run_overlay_core.py feature set or a reduced detection + ghost subset. (Decision deferred but should be made before Week 1 start.)

    Provide Sample Data — collect 5–10 recorded gameplay clips across common resolutions and lighting conditions; include any labeled frames if available.

    Instrument Current Pipeline — add lightweight timing instrumentation to measure capture, preprocess, recognition, and prediction latencies.

    Runtime Hub Plugin Skeleton — create a Runtime Hub node that can start/stop the Python pipeline and surface calibration controls.

    Define Hardware Baseline — specify minimum target machine (CPU model, GPU presence) for performance testing.

    Create Test Harness — add integration tests that run the pipeline on recorded clips and assert detection accuracy and latency thresholds.

Additional Questions for Implementation Team

    Which repo should be the canonical Phase 1 codebase for active development and PRs? (Suggested: -tetris-overlay-test.)

    Can you provide 5–10 recorded gameplay clips covering typical and edge-case scenarios for validation?

    What is the minimum target hardware we must support for Phase 1 benchmarks?

    Do you want the capture adapter to support both windowed and fullscreen capture from the start?

    Who will own native C++ work if/when we move capture or recognition to native modules?

    Do you want telemetry at all in Phase 1 or defer to Phase 2?

    Any constraints on third-party libraries (e.g., no proprietary inference runtimes)?