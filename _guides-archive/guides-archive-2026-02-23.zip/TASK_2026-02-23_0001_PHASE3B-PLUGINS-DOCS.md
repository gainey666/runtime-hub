# TASK: Phase 3B — Plugin Expansion + Docs + API Fix

**From:** bigllm | **To:** windsurf ide ai
**Priority:** HIGH
**Phase 3A status:** Complete ✅ — good work

---

## CONTEXT

One leftover from 3A: API response time is 75.76ms vs the 20ms target. Investigate this first before building new things — it may affect plugin execution too.

---

## PART 1 — Fix API response time (leftover from 3A)

Current: 75.76ms. Target: <20ms.

Check these in order:
1. Is there middleware doing unnecessary work on every request (logging, DB reads, etc.)?
2. Is the server doing synchronous file I/O on the hot path in `src/server.js`?
3. Is it a cold-start issue? Time 3 consecutive calls — if first is slow and rest are fast, it's cold start and acceptable. Report the warm numbers.
4. If it's a real bottleneck, optimize it. If it's cold start only, document it and move on.

---

## PART 2 — Build 2 more useful plugins

The hello-world plugin proves the system works. Now build two that demonstrate real value:

### Plugin A: `plugins/logger-plugin/`
- Input: any data type
- Behavior: formats as timestamped log entry, writes to a log array accessible via API
- Output: passes data through unchanged (passthrough pattern)
- Config: log level (info/warn/error), optional label prefix
- At least 3 unit tests

### Plugin B: `plugins/data-transform-plugin/`
- Input: string or number
- Config options: uppercase, lowercase, trim, parse-as-number, parse-as-json
- Output: transformed value
- Error handling: if transform fails, output `{ error: "reason", original: value }`
- At least 3 unit tests

Both must appear in the node editor palette when the app starts and execute correctly in a workflow.

---

## PART 3 — Plugin developer documentation

Create `public-docs/PLUGIN-DEVELOPMENT.md` covering:
1. What a plugin is (plain English, 2-3 sentences)
2. Exact file structure with explanation
3. Plugin manifest — every field, types, required vs optional
4. Port definitions — input/output types supported
5. Executor function — signature, inputs, how to return output, how to signal errors
6. Step-by-step tutorial building the logger-plugin from scratch
7. How to write and run plugin tests
8. Top 5 things that go wrong (troubleshooting)

---

## PART 4 — API reference doc

Create `public-docs/API-REFERENCE.md`.

For every endpoint in `src/server.js` document:
- Method + path
- One-line description
- Request body (fields + types)
- Response format with example JSON
- Error responses

---

## PART 5 — Update existing public-docs

Scan `public-docs/` for anything that references the old monolithic `workflow-engine.js` or predates the Phase 2 refactor. Update only what's wrong or missing — don't rewrite what's still accurate.

---

## 📤 REPORT BACK

File: `guides back/DONE_2026-02-23_PHASE3B-COMPLETE.md`

Include:
1. API response time — warm numbers, was it cold start or real issue?
2. Both plugins confirmed working in palette + workflow execution
3. Test results for new plugin tests
4. List of docs files created/updated
5. All git commit hashes
