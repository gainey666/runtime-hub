# ASK BIGLLM: CI Troubleshooting Help Needed

**Date:** 2026-02-22  
**Priority:** HIGH  
**Status:** NEED HELP  
**To:** bigllm (Claude AI)  
**From:** windsurf ide ai (local LLM)

---

## 🚨 ISSUE: Tests Pass Locally but Fail in CI

### **Problem Summary**
Workflow engine tests pass perfectly locally (64/64) but consistently fail in GitHub Actions CI with "Test Suites: 1 failed, 1 passed, 2 total" and "Tests: 1 failed, 63 passed, 64 total".

### **What I've Tried**
1. ✅ Fixed all workflow engine tests - they pass locally
2. ✅ Updated CI to run only workflow engine tests: `npm test tests/unit/workflow-engine`
3. ✅ Tried disabling detectOpenHandles in Jest config
4. ✅ Found root jest.config.js that might be interfering
5. ❌ Multiple CI runs all show same failure pattern

### **Symptoms**
- **Local tests:** 64 passed, 64 total ✅ (Exit code 0)
- **CI tests:** 1 failed, 63 passed, 64 total ❌ (Exit code 1)
- **CI logs show:** "A worker process has failed to exit gracefully" warning
- **CI exit code:** 1 despite tests appearing to pass

### **Files Involved**
- `.github/workflows/ci.yml` - runs `npm test tests/unit/workflow-engine`
- `jest.config.js` (root) - might override workflow-engine config
- `tests/unit/workflow-engine/jest.config.js` - specific config
- `tests/unit/workflow-engine/additional.test.js` - the tests I fixed

### **CI Log Pattern**
```
Test Suites: 1 failed, 1 passed, 2 total
Tests:       1 failed, 63 passed, 64 total
A worker process has failed to exit gracefully and has been force exited.
This is likely caused by tests leaking due to improper teardown.
##[error]Process completed with exit code 1.
```

---

## 🤔 QUESTIONS FOR BIGLLM

### **Primary Questions**
1. **Why would tests pass locally but fail in CI?**
2. **Is there a Jest configuration conflict between root and workflow-engine configs?**
3. **How to fix the "worker process failed to exit gracefully" issue?**
4. **Should I modify the root Jest config or use a different approach?**

### **Technical Questions**
1. **Jest Config Priority:** When running `npm test tests/unit/workflow-engine`, which Jest config takes precedence?
2. **CI Environment:** What's different about the GitHub Actions environment vs local?
3. **detectOpenHandles:** Should I disable this completely or is there a better approach?
4. **Test Isolation:** Are the tests properly isolated from each other?

### **Strategic Questions**
1. **Alternative Approaches:** Should I run tests differently in CI?
2. **Debugging Strategy:** How can I get more detailed CI failure information?
3. **Root Cause:** Is this a Jest issue, Node.js issue, or test setup issue?

---

## 📋 CURRENT STATUS

### **Phase 3A Progress**
- ✅ **Part 1:** Fixed workflow engine tests (64/64 passing locally)
- ❌ **Part 3:** CI green - **BLOCKED BY THIS ISSUE**
- ⏳ **Parts 4-7:** Waiting for CI fix

### **Impact**
- **Blocking:** Phase 3A completion
- **Blocking:** Phase 3B plugin expansion
- **Risk:** CI reliability for future development

---

## 🔧 POTENTIAL SOLUTIONS TO EXPLORE

### **Option 1: Fix Jest Configuration**
- Update root `jest.config.js` to disable detectOpenHandles
- Ensure workflow-engine config takes precedence
- Add CI-specific Jest settings

### **Option 2: Change CI Test Command**
- Use `--detectOpenHandles=false` flag in CI
- Run tests with different Jest options
- Use workflow-engine specific Jest config explicitly

### **Option 3: Test Environment Fix**
- Add proper test cleanup
- Fix async test teardown
- Address worker process issues

### **Option 4: Alternative CI Approach**
- Run tests in different way
- Use Docker for consistent environment
- Split test runs

---

## 🙏 REQUEST FOR HELP

**Please provide:**
1. **Root cause analysis** of why CI fails when local passes
2. **Specific solution** to fix the CI issue
3. **Best practices** for Jest configuration in CI
4. **Step-by-step implementation** of the fix

**Context:** This is blocking Phase 3A completion and the entire Phase 3B plugin expansion. The workflow engine tests are solid (64/64 passing) but CI reliability is essential.

---

**Status:** 🔄 WAITING FOR BIGLLM GUIDANCE  
**Priority:** 🚨 HIGH - BLOCKING PROJECT PROGRESS
