# ANSWER: Integration Test — Exact Root Cause + Fix

**From:** bigllm | **To:** windsurf ide ai
**Stop guessing. Here is the exact problem.**

---

## WHAT IS ACTUALLY BROKEN

Open `tests/integration/workflow-e2e.test.js`.

The file has this at the top:
```javascript
const { app } = require('../../src/server');
```

Good. But then EVERY SINGLE HTTP CALL in all 6 tests uses:
```javascript
const response = await request(serverUrl)
  .post('/api/workflows')
  ...
```

**`serverUrl` is never declared or defined anywhere in this file.** It is `undefined`. Every test is calling `request(undefined)` which either errors immediately or connects to the wrong place. That's why tests fail or hang — the HTTP calls are all broken.

This is the ONLY reason the tests aren't working. Fix this one thing and the tests will run.

---

## THE FIX — Two changes, 10 minutes

### Change 1 — workflow-e2e.test.js: replace all `request(serverUrl)` with `request(app)`

The file already imports `app` correctly. Just use it. Do a find-and-replace across the entire file:

**Find:** `request(serverUrl)`
**Replace with:** `request(app)`

There are approximately 15 occurrences. Replace ALL of them.

Also move `process.env.DISABLE_PLUGINS = 'true'` to the very top of the file, BEFORE the require — the require runs immediately at module load, before any beforeAll ever fires:

```javascript
// At the very top, BEFORE any require:
process.env.DISABLE_PLUGINS = 'true';
process.env.NODE_ENV = 'test';

const request = require('supertest');
const { app } = require('../../src/server');

describe('Workflow E2E Integration Tests', () => {
  // No more beforeAll needed for env vars - they're already set above

  describe('1. Happy Path...', () => {
    test('should execute...', async () => {
      const response = await request(app)   // <-- app, not serverUrl
        .post('/api/workflows')
        .send(workflow)
        .expect(200);
      // ...
    });
  });
});
```

### Change 2 — server.js: use in-memory SQLite during tests

Line 84 of server.js opens a real SQLite file on every `require()`:
```javascript
const db = new sqlite3.Database(config.database.path);
```

This creates an open file handle that can keep the process alive. Change it to:
```javascript
const dbPath = process.env.NODE_ENV === 'test' ? ':memory:' : config.database.path;
const db = new sqlite3.Database(dbPath);
```

Jest automatically sets `NODE_ENV=test`, so this will use an in-memory database during all tests — no file handle, no cleanup needed.

---

## ALSO ADD — afterAll to close properly

In `workflow-e2e.test.js`, add at the top level of the describe block:

```javascript
const { app, io } = require('../../src/server');

// ... tests ...

afterAll((done) => {
  io.close(done);
});
```

This closes the Socket.IO server after integration tests finish, which releases its event listeners cleanly.

---

## WHY THE SIGINT MESSAGES

The SIGINT handlers in server.js are now correctly inside `require.main === module`, so they should NOT fire during Jest tests. If you're still seeing them, it means you or Windsurf pressed Ctrl+C to stop the hanging test — that Ctrl+C IS the SIGINT. The message will only appear if the signal handlers somehow got registered. Double-check: grep server.js for `SIGINT` and confirm BOTH occurrences are inside the `if (require.main === module)` block.

---

## SUMMARY

1. Replace all `request(serverUrl)` → `request(app)` in workflow-e2e.test.js (~15 occurrences)
2. Move `process.env.DISABLE_PLUGINS = 'true'` to top of file, before require
3. Change server.js line 84 to use `:memory:` when `NODE_ENV === 'test'`
4. Add `afterAll` to close `io`

Run: `npx jest tests/integration/workflow-e2e.test.js --verbose`

If any test fails after this, it will be a real assertion failure with a clear error message — not a hang.
