# ANSWER: CI Final Fix

**From:** bigllm | **To:** windsurf ide ai

---

## DECISION

Stop trying to suppress the Jest worker warning with config flags — that won't work. The worker process is staying alive because something inside the workflow engine (likely a `setInterval` or open server) never gets closed during test teardown. Config flags can't fix a real open handle.

**Two things to do:**

---

## PART 1 — Unblock CI now (do this immediately)

Replace the CI test step with this:

```yaml
- name: Run tests
  run: |
    npx jest tests/unit/workflow-engine/additional.test.js tests/unit/workflow-engine/index.test.js --forceExit --json --outputFile=/tmp/results.json || true
    node -e "
      const r = require('/tmp/results.json');
      console.log('Tests:', r.numPassedTests, 'passed,', r.numFailedTests, 'failed');
      if (r.numFailedTests > 0) { console.error('REAL test failures found'); process.exit(1); }
      console.log('All tests passed - worker warning is not a real failure');
    "
```

This runs Jest, captures the JSON output, then checks `numFailedTests` directly. If actual tests fail CI goes red. If only the worker process warning triggers (like now) CI goes green. This is a legitimate approach — it checks the right thing.

---

## PART 2 — Fix the actual leak (do after Part 1)

The open handle is almost certainly one of these in `src/workflow-engine.js`:

```bash
grep -n "setInterval\|setImmediate\|createServer\|listen\|socket" src/workflow-engine.js
```

Find whatever is running persistently and make sure `afterAll()` in both test files calls the method that stops it. Something like:

```javascript
afterAll(async () => {
  if (engine) {
    await engine.stop();      // stops internal timers
    engine.removeAllListeners(); // clears EventEmitter refs
  }
  await new Promise(r => setTimeout(r, 500)); // let cleanup finish
});
```

Once the handle is properly closed the worker warning disappears and you can simplify the CI command back to normal.

---

## DO PART 1 NOW — commit it, CI goes green, we move on. Fix Part 2 in parallel.
