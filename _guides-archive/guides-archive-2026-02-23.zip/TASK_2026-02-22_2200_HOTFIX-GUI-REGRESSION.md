# TASK: HOTFIX — GUI Visual Regression (Do This First, Before 2A)

**From:** bigllm | **To:** windsurf ide ai
**Priority:** CRITICAL — blocks all other Phase 2 work
**Do this BEFORE:** Any Phase 2 tasks

---

## 🎯 PROBLEM SUMMARY

The node editor GUI has regressed visually from a recent change. Symptoms reported by user:

1. **Wrong colors everywhere** — the whole color scheme is different from before
2. **Everything pushed to the right** — background, node palette are offset/misaligned
3. **Buttons cut off or off-screen** — except top toolbar buttons (those are in place but wrong color)
4. **Node palette is misaligned** — shoved to the right side

User suspects it's related to resolution or layout fixes made in a recent session.

---

## 📋 STEPS TO DIAGNOSE

### Step 1 — Git Blame
```bash
git log --oneline -10
git diff HEAD~1 HEAD -- public/node-editor.html
git diff HEAD~2 HEAD -- public/node-editor.html
```
Look for recent changes to: CSS variables, `width`/`height`, `position`, `flex`, `grid`, `transform`, `zoom`, `margin`, `padding`, `background`, `color`.

### Step 2 — Identify Root Cause Category
Likely culprits (check in this order):
1. **CSS custom properties** (`--color-*`, `--bg-*`) were changed or removed
2. **Layout container broke** — a `display: flex` or `display: grid` on the root/canvas container got removed or changed
3. **Offset/transform** — a `transform: translateX()` or `margin-left` is pushing content right
4. **Viewport/scaling** — a `zoom` or `transform: scale()` is miscalculated for the current resolution

---

## 📋 ACCEPTANCE CRITERIA

- [ ] Color scheme matches the original (check git history for what it was before)
- [ ] Canvas area fills its correct space (not pushed right)
- [ ] Node palette is left-aligned or wherever it was originally
- [ ] All toolbar buttons visible and correctly colored
- [ ] Nothing cut off at any standard window size (1920×1080, 1366×768)
- [ ] 31/31 tests still pass
- [ ] App is interactable — nodes can be dragged, buttons respond

---

## 🔍 WHERE TO LOOK

```
public/node-editor.html     ← all CSS and layout (primary target)
```

Focus on:
- `:root` CSS variable block (colors)
- The outermost layout containers (body, `#app`, `#main-container` or equivalent)
- Any `position: absolute` or `position: fixed` elements that might be mis-anchored

---

## ⚠️ CONSTRAINTS

- Fix the regression only — restore to last known good state
- Do not add new features or refactor while fixing this
- If you can't find the cause in git diff, check if any external CSS file is missing or mis-linked

---

## 📤 REPORT BACK

File: `guides back/DONE_2026-02-22_HOTFIX-GUI-REGRESSION.md`
Include:
1. What commit/change caused the regression (if found)
2. What specifically was broken and what you changed to fix it
3. Test results (31/31)
4. Git commit hash

Blocker? → `guides back/BLOCKED_2026-02-22_HOTFIX-GUI-REGRESSION.md`
